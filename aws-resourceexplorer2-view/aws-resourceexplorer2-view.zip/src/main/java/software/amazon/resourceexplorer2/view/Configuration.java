package software.amazon.resourceexplorer2.view;

class Configuration extends BaseConfiguration {

    public Configuration() {
        super("aws-resourceexplorer2-view.json");
    }
}
